from mpl_toolkits.mplot3d import Axes3D
import numpy as np
from matplotlib import pyplot as plt

filename='data.txt'


def read_data(filename): #read from file and return data as an numpy array


def compute_cost(X,y,theta): #Compute cost J(x) using the cost function and return cost per iteration


def gradient_descent(X,y,theta,alpha,num_iterations): # Implement gradient descent - should return updated theta values

#==============================Your Work==============================
data=read_data(filename)

x,y=data[:,0],data[:,1]

X= # Add a column of ones, for the bias parameter

theta= #Intially Zeros
compute_cost(X,y,theta)
theta=gradient_descent(X,y,theta,alpha=0.01,num_iterations=1500)

#==============================Work Ends Here=========================

# Visualization of the data Set

plt.scatter(x,y)
plt.plot(X[:,1],np.dot(X,theta),c='r')
plt.show()

theta0_vals=np.linspace(-10,10,100)
theta1_vals=np.linspace(-1,4,100)

j_vals=np.zeros((len(theta0_vals),len(theta1_vals)))

for i in xrange(len(theta0_vals)):
	for j in xrange(len(theta1_vals)):
		t=np.array([theta0_vals[i],theta1_vals[j]])
		j_vals[i,j]=compute_cost(X,y,t)

fig=plt.figure()
ax=fig.add_subplot(111)
ax.contour(theta0_vals,theta1_vals,j_vals.T,np.logspace(-2,3,20))
ax.scatter(theta[0],theta[1],c='r',marker='+',s=100)
plt.show()
